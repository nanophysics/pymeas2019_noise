uv run --with=git+https://github.com/nanophysics/pymeas2019_noise.git -- python -m pymeas2019_noise.run_0_measure
echo ERRORLEVEL %ERRORLEVEL%
pause