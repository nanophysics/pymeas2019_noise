uv run --with=git+https://github.com/nanophysics/pymeas2019_noise.git -- python -m pymeas2019_noise.run_2_composite_plots
echo ERRORLEVEL %ERRORLEVEL%
pause