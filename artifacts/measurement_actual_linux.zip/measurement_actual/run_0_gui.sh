#!/usr/bin/env bash
# You may need to add the execution bit: chmod a+x *.sh
set -eu

uv run --with=git+https://github.com/nanophysics/pymeas2019_noise.git -- python -m pymeas2019_noise.run_0_gui